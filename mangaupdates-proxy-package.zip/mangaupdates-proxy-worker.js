const MANGAUPDATES_API_BASE = "https://api.mangaupdates.com/v1";
const ALLOWED_ORIGINS = ["*"]; // Replace "*" with your site URL later if you want to lock it down.

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": ALLOWED_ORIGINS[0],
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Accept",
  "Access-Control-Max-Age": "86400"
};

function jsonResponse(body, status = 200, extraHeaders = {}) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      ...CORS_HEADERS,
      ...extraHeaders
    }
  });
}

function withCors(response) {
  const headers = new Headers(response.headers);
  for (const [key, value] of Object.entries(CORS_HEADERS)) {
    headers.set(key, value);
  }
  return new Response(response.body, {
    status: response.status,
    statusText: response.statusText,
    headers
  });
}

function isAllowedPath(pathname, method) {
  if (method === "POST" && pathname === "/series/search") return true;
  if (method === "GET" && /^\/series\/[^/]+$/.test(pathname)) return true;
  if (method === "GET" && /^\/series\/[^/]+\/rss$/.test(pathname)) return true;
  return false;
}

export default {
  async fetch(request) {
    const requestUrl = new URL(request.url);
    const method = request.method.toUpperCase();

    if (method === "OPTIONS") {
      return new Response(null, { status: 204, headers: CORS_HEADERS });
    }

    if (!isAllowedPath(requestUrl.pathname, method)) {
      return jsonResponse({ error: "Not allowed" }, 404);
    }

    const targetUrl = new URL(`${MANGAUPDATES_API_BASE}${requestUrl.pathname}`);
    targetUrl.search = requestUrl.search;

    const headers = new Headers();
    headers.set("Accept", request.headers.get("Accept") || "application/json, text/plain, */*");

    let body;
    if (method !== "GET" && method !== "HEAD") {
      body = await request.text();
      headers.set("Content-Type", request.headers.get("Content-Type") || "application/json");
    }

    try {
      const upstream = await fetch(targetUrl.toString(), {
        method,
        headers,
        body
      });

      return withCors(upstream);
    } catch (error) {
      return jsonResponse({ error: error.message || "MangaUpdates proxy request failed" }, 502);
    }
  }
};
