MangaUpdates proxy setup

1. Create a Cloudflare Worker.
2. Paste mangaupdates-proxy-worker.js into the Worker editor.
3. Deploy it and copy the Worker URL, for example:
   https://your-worker-name.your-subdomain.workers.dev
4. In release-board-manga.html, change:
   const MANGAUPDATES_PROXY_ENDPOINT = "";
   to:
   const MANGAUPDATES_PROXY_ENDPOINT = "https://your-worker-name.your-subdomain.workers.dev";
5. Reload the HTML and try adding/refreshing a manga again.

The Worker only forwards these MangaUpdates API paths:
- POST /series/search
- GET /series/{id}
- GET /series/{id}/rss

It is intentionally not an open proxy.
